# pickit

Modulo de Pickit

Para modulos con OnePageCheckout:
usar la estructura de onepagecheckout y pegar el archivo available.phtml en la carpeta de shipping-method
