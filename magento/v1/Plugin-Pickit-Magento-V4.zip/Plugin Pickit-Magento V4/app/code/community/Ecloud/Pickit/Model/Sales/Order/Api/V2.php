<?php
/**
 * Order API V2
 *
 * @category   Mage
 * @package    Mage_Sales
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Ecloud_Pickit_Model_Sales_Order_Api_V2 extends Ecloud_Pickit_Model_Sales_Order_Api
{

}
